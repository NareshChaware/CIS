import { Partner } from './partner';

describe('Partner', () => {
  it('should create an instance', () => {
    expect(new Partner()).toBeTruthy();
  });
});
