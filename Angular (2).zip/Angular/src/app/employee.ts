export class Employee {

    employee_id:number;
    employee_fName:String;
    employee_lName:String;
    employee_email:String;
    employee_phone:String;
    employee_status:String;
}
