import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subject } from "rxjs";
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

 constructor(private employeeService:EmployeeService) { }

  employeesArray: any[] = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any>= new Subject();


  employees: Observable<Employee[]>;
  employee : Employee=new Employee();
  deleteMessage=false;
  employeeList:any;
  isupdated = false;    
 

  ngOnInit() {
    this.isupdated=false;
    this.dtOptions = {
      pageLength: 6,
      stateSave:true,
      lengthMenu:[[6, 16, 20, -1], [6, 16, 20, "All"]],
      processing: true
    };   
    this.employeeService.getEmployeeList().subscribe(data =>{
    this.employees =data;
    this.dtTrigger.next();
    })
  }
  
  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          this.deleteMessage=true;
          this.employeeService.getEmployeeList().subscribe(data =>{
            this.employees =data
            })
        },
        error => console.log(error));
  }


  updateEmployee(id: number){
    this.employeeService.getEmployee(id)
      .subscribe(
        data => {
          this.employeeList=data           
        },
        error => console.log(error));
  }

  employeeUpdateForm=new FormGroup({
    employee_id:new FormControl(),
    employee_fName:new FormControl(),
    employee_lName:new FormControl(),
    employee_email:new FormControl(),
    employee_phone:new FormControl(),
    employee_status:new FormControl()
  });

  updateStu(updstu){
    this.employee=new Employee(); 
   this.employee.employee_id=this.EmployeeId.value;
   this.employee.employee_fName=this.EmployeeFName.value;
   this.employee.employee_lName=this.EmployeeLName.value;
   this.employee.employee_email=this.EmployeeEmail.value;
   this.employee.employee_status=this.EmployeeStatus.value;
   this.employee.employee_phone=this.EmployeePhone.value;
   
   this.employeeService.updateEmployee(this.employee.employee_id,this.employee).subscribe(
    data => {     
      this.isupdated=true;
      this.employeeService.getEmployeeList().subscribe(data =>{
        this.employees =data
        })
    },
    error => console.log(error));
  }

  get EmployeeFName(){
    return this.employeeUpdateForm.get('employee_fName');
  }

  get EmployeeLName(){
    return this.employeeUpdateForm.get('employee_lName');
  }

  get EmployeeEmail(){
    return this.employeeUpdateForm.get('employee_email');
  }

  get EmployeePhone(){
    return this.employeeUpdateForm.get('employee_phone');
  }

  get EmployeeStatus(){
    return this.employeeUpdateForm.get('employee_status');
  }

   get EmployeeId(){
     return this.employeeUpdateForm.get('employee_id');
   }

  changeisUpdate(){
    this.isupdated=false;
  }
}
