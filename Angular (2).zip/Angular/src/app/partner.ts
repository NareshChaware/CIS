export class Partner {
    id:number;
    partnerName:String;
    partnerEmail:String;


}
