import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor(private employeeService:EmployeeService) { }

  employee : Employee=new Employee();
  submitted = false;

  ngOnInit() {
    this.submitted=false;
  }

  addUpdateContactForm=new FormGroup({
    employee_fName:new FormControl('' , [Validators.required , Validators.minLength(3), Validators.maxLength(50) ] ),
    employee_lName:new FormControl('' , [Validators.required , Validators.minLength(3), Validators.maxLength(50) ] ),
    employee_email:new FormControl('',[Validators.required,Validators.email]),
    employee_phone:new FormControl('',[Validators.required, Validators.minLength(10), Validators.maxLength(13)]),
    employee_status:new FormControl()
  });

  addContact(addContact){
    this.employee=new Employee();   
    this.employee.employee_fName=this.EmployeeFName.value;
    this.employee.employee_lName=this.EmployeeLName.value;
    this.employee.employee_email=this.EmployeeEmail.value;
    this.employee.employee_phone=this.EmployeePhone.value;
    this.employee.employee_status=this.EmployeeStatus.value;
    this.submitted = true;
    this.save();
  }

  

  save() {
    this.employeeService.createEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
  }

  get EmployeeFName(){
    return this.addUpdateContactForm.get('employee_fName');
  }

  get EmployeeLName(){
    return this.addUpdateContactForm.get('employee_lName');
  }

  get EmployeeEmail(){
    return this.addUpdateContactForm.get('employee_email');
  }

  get EmployeePhone(){
    return this.addUpdateContactForm.get('employee_phone');
  }

  get EmployeeStatus(){
    return this.addUpdateContactForm.get('employee_status');
  }

  addEmployeeForm(){
    this.submitted=false;
    this.addUpdateContactForm.reset();
  }
}
