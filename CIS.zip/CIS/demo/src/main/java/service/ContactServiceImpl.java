package service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.ContactDAO;
import model.Contact;

@Service
@Transactional
public class ContactServiceImpl implements ContactService {

	static final Logger LOG = LoggerFactory.getLogger(ContactServiceImpl.class);

	@Autowired
	private ContactDAO contactDao;

	@Override
	public boolean saveEmployee(Contact contact) {
		LOG.info("Starting saveEmployee..contact{}..", contact);

		return contactDao.saveEmployee(contact);
	}

	@Override
	public List<Contact> getEmployees() {
		LOG.info("Starting getEmployees..");

		return contactDao.getEmployees();
	}

	@Override
	public boolean deleteEmployee(Contact contact) {
		LOG.info("Starting deleteEmployee..contact{}..", contact);

		return contactDao.deleteEmployee(contact);
	}

	@Override
	public List<Contact> getEmployeeByID(Contact contact) {
		LOG.info("Starting getEmployeeByID..contact{}..", contact);

		return contactDao.getEmployeeByID(contact);
	}

	@Override
	public boolean updateEmployee(Contact contact) {
		LOG.info("Starting updateEmployee..contact{}..", contact);

		return contactDao.updateEmployee(contact);
	}

}
