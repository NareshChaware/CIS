package service;

import java.util.List;

import model.Contact;

public interface ContactService {

	public boolean saveEmployee(Contact contact);

	public List<Contact> getEmployees();

	public boolean deleteEmployee(Contact contact);

	public List<Contact> getEmployeeByID(Contact contact);

	public boolean updateEmployee(Contact contact);
}
