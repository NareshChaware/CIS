package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Contact;

@Repository
public class ContactDAOImpl implements ContactDAO {

	static final Logger LOG = LoggerFactory.getLogger(ContactDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public boolean saveEmployee(Contact contact) {
		LOG.info("Starting saveEmployee..contact{}..", contact);

		boolean status = false;
		try {
			sessionFactory.getCurrentSession().save(contact);
			status = true;
		} catch (Exception e) {
			throw e;
		}
		return status;
	}

	@Override
	public List<Contact> getEmployees() {
		LOG.info("Starting getEmployees..");

		Session currentSession = sessionFactory.getCurrentSession();
		Query<Contact> query = currentSession.createQuery("from Contact", Contact.class);
		List<Contact> list = query.getResultList();
		return list;
	}

	@Override
	public boolean deleteEmployee(Contact contact) {
		LOG.info("Starting deleteEmployee..contact{}..", contact);

		boolean status = false;
		try {
			sessionFactory.getCurrentSession().delete(contact);
			status = true;
		} catch (Exception e) {
			throw e;
		}
		return status;
	}

	@Override
	public List<Contact> getEmployeeByID(Contact contact) {
		LOG.info("Starting getEmployeeByID..contact{}..", contact);

		Session currentSession = sessionFactory.getCurrentSession();
		Query<Contact> query = currentSession.createQuery("from Contact where employee_id=:employee_id", Contact.class);
		query.setParameter("employee_id", contact.getEmployee_id());
		List<Contact> list = query.getResultList();
		return list;
	}

	@Override
	public boolean updateEmployee(Contact contact) {
		LOG.info("Starting updateEmployee..contact{}..", contact);

		boolean status = false;
		try {
			sessionFactory.getCurrentSession().update(contact);
			status = true;
		} catch (Exception e) {
			throw e;
		}
		return status;
	}

}
