package controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Contact;
import service.ContactService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/api")
public class ContactController {

	static final Logger LOG = LoggerFactory.getLogger(ContactController.class);

	@Autowired
	private ContactService contactService;

	@SuppressWarnings("unused")
	@PostMapping("save-employee")
	public boolean saveEmployee(@RequestBody Contact contact) {
		LOG.info("Starting saveEmployee.....contact{}...", contact.toString());
		try {
			if (contact != null) {
				return contactService.saveEmployee(contact);
			} else {
				LOG.info("There are no data.....");
				return false;
			}
		} catch (Exception ex) {
			LOG.info("Error while saving the contact data.....", ex);
			return false;
		}
	}

	@GetMapping("employees-list")
	public List<Contact> allEmployees() {
		LOG.info("Starting allEmployees....");

		try {
			return contactService.getEmployees();
		} catch (Exception ex) {
			LOG.info("Error while fetching employees data....");
			throw ex;
		}
	}

	@DeleteMapping("delete-employee/{employee_id}")
	public boolean deleteEmployee(@PathVariable("employee_id") int employee_id, Contact contact) {
		LOG.info("Starting deleteEmployee....employee_Id{}..contact{}..", employee_id, contact.toString());

		try {
			if (employee_id > 0) {
				contact.setEmployee_id(employee_id);
				return contactService.deleteEmployee(contact);
			} else {
				LOG.info("No data found....employee_id{}..", employee_id);
				return false;
			}
		} catch (Exception ex) {
			LOG.info("Error while deleting the data...", ex);
			return false;
		}
	}

	@GetMapping("employee/{employee_id}")
	public List<Contact> allEmployeeByID(@PathVariable("employee_id") int employee_id, Contact contact) {
		LOG.info("Starting allEmployeeByID..employee_id{}..contact{}..", employee_id, contact.toString());

		try {
			if (employee_id > 0) {
				contact.setEmployee_id(employee_id);
				return contactService.getEmployeeByID(contact);
			} else {
				LOG.info("No data found..employee_id{}..contact{}..", employee_id, contact.toString());
				return null;
			}
		} catch (Exception ex) {
			LOG.info("Error while fetching employee...employee_id{}..contact{}..", employee_id, contact.toString());
			return null;
		}
	}

	@PostMapping("update-employee/{employee_id}")
	public boolean updateEmployee(@RequestBody Contact contact, @PathVariable("employee_id") int employee_id) {
		LOG.info("Starting updateEmployee..contact{}..employee_id{}..", contact.toString(), employee_id);
		try {
			if (employee_id > 0) {
				contact.setEmployee_id(employee_id);
				return contactService.updateEmployee(contact);
			} else {
				LOG.info("No data found..contact{}..employee_id{}..", contact.toString(), employee_id);
				return false;
			}
		} catch (Exception ex) {
			LOG.info("Error while fetching data..contact{}..employee_id{}..", contact.toString(), employee_id);
			return false;
		}
	}

}
